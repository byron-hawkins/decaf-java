
/* SWIG version information */

#ifndef SWIG_VERSION
#define SWIG_VERSION "1.3.16u-20021213-1936"
#endif

#ifndef SWIG_MAJOR_VERSION
#define SWIG_MAJOR_VERSION 1
#endif

#ifndef SWIG_MINOR_VERSION
#define SWIG_MINOR_VERSION 3
#endif

#ifndef SWIG_SPIN
#define SWIG_SPIN 16
#endif
