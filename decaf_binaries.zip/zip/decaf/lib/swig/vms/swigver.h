
/* SWIG version information */

#ifndef SWIG_VERSION
#define SWIG_VERSION 0x010316
#endif

#ifndef SWIG_MAJOR_VERSION
#define SWIG_MAJOR_VERSION 1
#endif

#ifndef SWIG_MINOR_VERSION
#define SWIG_MINOR_VERSION 3
#endif

#ifndef SWIG_SPIN
#define SWIG_SPIN 16
#endif
